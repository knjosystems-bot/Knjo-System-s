# KNJO Core V1 Alpha3 — lista previa al deploy

## Estado de este paquete

- `npm run predeploy-check`: valida archivos críticos, sintaxis JavaScript, rutas, módulo ES, PWA, dependencias declaradas e inicialización de Blobs para handlers Lambda-compatible.
- Este chequeo es estático; no sustituye la prueba de integración contra Netlify Blobs ni la validación del login en producción. El endpoint `/health` no debe interpretarse como prueba de persistencia.
- El proyecto requiere un deploy con funciones Netlify. No usar un despliegue estático de solo `public/`.

## Deploy recomendado desde la raíz del proyecto

1. Instalar Node.js 22 o superior.
2. Ejecutar `npm run predeploy-check`.
3. Ejecutar `npm install` y comprobar que termina correctamente.
4. En Netlify, comprobar para el contexto **Production** que están configuradas:
   - `AUTH_USERNAME`: usuario único de 3–64 caracteres; solo letras, números, punto, guion o guion bajo.
   - `AUTH_PASSWORD_HASH`: hash scrypt generado por `node scripts/hash-password.mjs`; nunca la contraseña en texto plano.
   - Ambas variables deben estar disponibles para **Functions/Runtime**.
5. Confirmar que el sitio seleccionado es `knjocore.netlify.app` y que las variables están disponibles para Functions/Runtime. No crear ni sustituir `NETLIFY_AUTH_TOKEN` si no se ha verificado el método de acceso actual a Blobs.
6. Cuando los chequeos estén completos, desplegar el ZIP completo en el sitio correcto. No subir únicamente la carpeta `public/`.
7. En el deploy publicado, confirmar las funciones: `auth-login`, `auth-me`, `auth-csrf`, `auth-logout`, `health`, `tasks`, `tasks-update`, `tasks-delete`.

## Pruebas de aceptación posteriores al deploy

- `GET /health` devuelve HTTP 200 y confirma únicamente liveness. El almacenamiento aparece `not-checked` hasta implementar y probar una comprobación real de lectura en Blobs.
- Inicio de sesión correcto devuelve HTTP 200 y establece cookies seguras.
- Contraseña incorrecta devuelve HTTP 401; ausencia o formato inválido de variables devuelve HTTP 503.
- Crear tarea devuelve HTTP 201; al recargar, la tarea persiste.
- Editar tarea devuelve HTTP 200; cambiar estado y prioridad persiste.
- Eliminar tarea devuelve HTTP 200 y deja de aparecer.
- Cerrar sesión invalida la sesión; las rutas privadas sin sesión devuelven HTTP 401.
- En Android/Chrome, instalar la PWA y verificar que la interfaz carga. La persistencia de tareas depende de Netlify Blobs.

## Seguridad

No guardes credenciales reales en archivos, repositorios, ZIPs, capturas ni mensajes. No declares listo el sistema hasta completar las pruebas de aceptación. Esta versión alpha no es una certificación de seguridad.
