/* PWA registration: caches only the public application shell, never API/auth responses. */
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {
      // Installation remains available only when the browser can register the worker.
    });
  });
}
