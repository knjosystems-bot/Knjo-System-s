import { installAIStudio } from './ai-studio.js';
const KNJO_TASKS_V02 = true;
const $ = (id) => document.getElementById(id);
// KNJO Core task UI. DOM nodes and textContent are used instead of HTML interpolation.
export function installTaskUI({ request, getCsrfToken, root }) {
  const existingPanel = document.getElementById('knjo-tasks');
  if (existingPanel) return existingPanel.__knjoTasksController ?? { refresh: async () => {} };
  const panel = document.createElement('section'); panel.id = 'knjo-tasks'; panel.setAttribute('aria-labelledby','knjo-tasks-heading');
  panel.innerHTML = `<h2 id="knjo-tasks-heading">GESTIÓN DE TAREAS</h2><form id="kt-create" class="kt-grid"><input name="title" required maxlength="200" placeholder="Nueva tarea" aria-label="Título de tarea"><select name="priority" aria-label="Prioridad"><option value="medium">Prioridad media</option><option value="low">Baja</option><option value="high">Alta</option><option value="urgent">Urgente</option></select><textarea class="kt-wide" name="description" maxlength="5000" placeholder="Descripción (opcional)" aria-label="Descripción"></textarea><input name="dueDate" type="date" aria-label="Fecha límite"><button type="submit">Crear tarea</button></form><p id="kt-message" class="kt-message" role="status" aria-live="polite"></p><div class="kt-filters"><input id="kt-search" placeholder="Buscar tareas" aria-label="Buscar tareas"><select id="kt-status" aria-label="Filtrar por estado"><option value="all">Todos los estados</option><option value="todo">Pendientes</option><option value="in_progress">En curso</option><option value="done">Terminadas</option><option value="cancelled">Canceladas</option></select><select id="kt-priority" aria-label="Filtrar por prioridad"><option value="all">Todas las prioridades</option><option value="low">Baja</option><option value="medium">Media</option><option value="high">Alta</option><option value="urgent">Urgente</option></select><select id="kt-due" aria-label="Filtrar por vencimiento"><option value="all">Todas las fechas</option><option value="overdue">Vencidas</option><option value="due_today">Vencen hoy</option><option value="upcoming">Próximas</option><option value="no_due_date">Sin fecha</option><option value="closed">Cerradas</option></select></div><div id="kt-list" class="kt-list"></div>`;
  root.append(panel);
  const $ = (id) => panel.querySelector(`#${id}`);
  const message = (text) => { $('kt-message').textContent = text; };
  const api = async (path, body) => request(path, { method: 'POST', headers: { 'x-csrf-token': getCsrfToken() }, body: JSON.stringify(body) });
  async function refreshTasks() {
    const params = new URLSearchParams({ status: $('kt-status').value, priority: $('kt-priority').value, due: $('kt-due').value, q: $('kt-search').value });
    try {
      const { body } = await request(`/api/tasks?${params}`);
      const list = $('kt-list'); list.replaceChildren();
      if (!body.tasks.length) { const empty = document.createElement('p'); empty.className = 'kt-meta'; empty.textContent = 'No hay tareas para estos filtros.'; list.append(empty); return; }
      for (const task of body.tasks) {
        const item = document.createElement('article'); item.className = 'kt-item';
        const today = new Date().toISOString().slice(0,10); const overdue = task.dueDate && task.dueDate < today && !['done','cancelled'].includes(task.status);
        if (overdue) item.classList.add('kt-overdue');
        const row = document.createElement('div'); row.className='kt-row';
        const title = document.createElement('div'); title.className='kt-title'; title.textContent=task.title;
        const priority = document.createElement('span'); priority.className='kt-meta'; priority.textContent=`Prioridad: ${{low:'Baja',medium:'Media',high:'Alta',urgent:'Urgente'}[task.priority] || task.priority}`;
        row.append(title,priority); item.append(row);
        if (task.description) { const desc=document.createElement('p'); desc.className='kt-meta'; desc.textContent=task.description; item.append(desc); }
        const meta=document.createElement('p'); meta.className='kt-meta'; meta.textContent=`Estado: ${{todo:'Pendiente',in_progress:'En curso',done:'Terminada',cancelled:'Cancelada'}[task.status] || task.status}${task.dueDate ? ` · Fecha límite: ${task.dueDate}${overdue?' · VENCIDA':''}` : ' · Sin fecha límite'}`; item.append(meta);
        const actions=document.createElement('div'); actions.className='kt-actions';
        const status=document.createElement('select'); status.setAttribute('aria-label',`Estado de ${task.title}`);
        for (const [value,label] of [['todo','Pendiente'],['in_progress','En curso'],['done','Terminada'],['cancelled','Cancelada']]) { const opt=document.createElement('option'); opt.value=value; opt.textContent=label; opt.selected=value===task.status; status.append(opt); }
        status.addEventListener('change', async()=>{ try { await api('/api/tasks/update',{id:task.id,status:status.value}); message('Estado actualizado.'); await refreshTasks(); } catch(e){ message(e.message); } });
        const remove=document.createElement('button'); remove.type='button'; remove.textContent='Eliminar'; remove.addEventListener('click',async()=>{ if(!confirm('¿Eliminar esta tarea?')) return; try { await api('/api/tasks/delete',{id:task.id}); message('Tarea eliminada.'); await refreshTasks(); } catch(e){ message(e.message); } });
        const edit=document.createElement('button'); edit.type='button'; edit.textContent='Editar';
        edit.addEventListener('click',()=>renderEditForm(task,item));
        actions.append(status,edit,remove); item.append(actions); list.append(item);
      }
    } catch(e) { message(`No se pudieron cargar las tareas: ${e.message}`); }
  }
  $('kt-create').addEventListener('submit',async(event)=>{ event.preventDefault(); const form=event.currentTarget; const data=new FormData(form); const dueDate=String(data.get('dueDate')||''); try { await api('/api/tasks',{title:String(data.get('title')).trim(),description:String(data.get('description')||''),priority:String(data.get('priority')||'medium'),...(dueDate?{dueDate}:{})}); form.reset(); form.elements.priority.value='medium'; message('Tarea creada.'); await refreshTasks(); } catch(e) { message(e.message); } });
  for (const id of ['kt-search','kt-status','kt-priority','kt-due']) $(id).addEventListener(id==='kt-search'?'input':'change',()=>refreshTasks());
  function renderEditForm(task,item) {
    const form=document.createElement('form'); form.className='kt-grid';
    const field=(name,label,type='text',value='')=>{ const el=document.createElement(type==='textarea'?'textarea':'input'); if(type!=='textarea') el.type=type; el.name=name; el.value=value ?? ''; el.setAttribute('aria-label',label); if(name==='title') {el.required=true;el.maxLength=200;} if(name==='description') el.maxLength=5000; return el; };
    const title=field('title','Título', 'text',task.title); title.className='kt-wide';
    const description=field('description','Descripción','textarea',task.description); description.className='kt-wide';
    const priority=document.createElement('select'); priority.name='priority'; priority.setAttribute('aria-label','Prioridad');
    for(const [value,label] of [['low','Baja'],['medium','Media'],['high','Alta'],['urgent','Urgente']]){const o=document.createElement('option');o.value=value;o.textContent=label;o.selected=value===task.priority;priority.append(o);}
    const statusEdit=document.createElement('select'); statusEdit.name='status'; statusEdit.setAttribute('aria-label','Estado');
    for(const [value,label] of [['todo','Pendiente'],['in_progress','En curso'],['done','Terminada'],['cancelled','Cancelada']]){const o=document.createElement('option');o.value=value;o.textContent=label;o.selected=value===task.status;statusEdit.append(o);}
    const due=field('dueDate','Fecha límite','date',task.dueDate);
    const save=document.createElement('button');save.type='submit';save.textContent='Guardar cambios';
    const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancelar';cancel.addEventListener('click',()=>refreshTasks());
    form.append(title,priority,description,statusEdit,due,save,cancel); item.replaceChildren(form);
    form.addEventListener('submit',async(event)=>{event.preventDefault();save.disabled=true;const data=new FormData(form);try{await api('/api/tasks/update',{id:task.id,title:String(data.get('title')).trim(),description:String(data.get('description')||''),priority:String(data.get('priority')),status:String(data.get('status')),dueDate:String(data.get('dueDate')||'')});message('Cambios guardados.');await refreshTasks();}catch(e){message(`No se pudieron guardar los cambios: ${e.message}`);save.disabled=false;}});
  }
  refreshTasks();
  const controller = { refresh: refreshTasks };
  panel.__knjoTasksController = controller;
  return controller;
}

const gate = $('gate'); const form = $('login-form'); const dashboard = $('dashboard');
let csrfToken = '';
async function request(path, options = {}) {
  const response = await fetch(path, { credentials: 'same-origin', cache: 'no-store', ...options, headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) } });
  const body = response.status === 204 ? null : await response.json().catch(() => null);
  if (!response.ok) { const error = new Error(body?.error?.message || 'La solicitud no pudo completarse.'); error.status = response.status; throw error; }
  return { body, response };
}
function showGate(openForm = false) { dashboard.classList.add('hidden'); gate.classList.remove('hidden'); form.classList.toggle('hidden', !openForm); if (openForm) $('username').focus(); }
function showDashboard() { gate.classList.add('hidden'); dashboard.classList.remove('hidden'); }
async function loadDashboard() {
  const { body: auth } = await request('/api/auth/me');
  $('account-name').textContent = auth.user.username;
  const { body: health } = await request('/health');
  const liveState = typeof health.liveness === 'string' ? health.liveness : health.liveness?.state;
  $('core-state').textContent = liveState === 'ok' ? 'Operativo' : 'No disponible';
  $('core-version').textContent = `Versión ${health.version}`;
  const provider = health.capabilities?.externalProviders;
  $('provider-state').textContent = provider?.verified === true && provider?.state === 'verified' ? 'Verificado' : (provider?.state === 'not-configured' ? 'No configurado' : 'No verificado');
  $('diagnostic').textContent = `Servicio: ${health.service}\nLiveness: ${liveState ?? 'desconocido'} (${health.liveness?.verified === true ? 'verificado' : typeof health.liveness === 'string' ? 'declarado' : 'no verificado'})\nAlmacenamiento: ${health.storage?.state ?? 'no informado'}\nProveedores externos: ${provider?.state ?? 'estado desconocido'}\nVerificación externa: ${provider?.verified === true ? 'confirmada' : 'no confirmada'}`;
  const tasksRoot = $('dashboard');
  installTaskUI({ request, getCsrfToken: () => csrfToken, root: tasksRoot });
  installAIStudio({ root: tasksRoot });
}
$('emblem-button').addEventListener('click', () => { form.classList.toggle('hidden'); if (!form.classList.contains('hidden')) $('username').focus(); });
form.addEventListener('submit', async (event) => {
  event.preventDefault(); const button = form.querySelector('button[type="submit"]'); const error = $('login-error'); error.textContent = ''; button.disabled = true;
  try {
    const { body } = await request('/api/auth/login', { method: 'POST', headers: {}, body: JSON.stringify({ username: $('username').value, password: $('password').value }) });
    csrfToken = body.csrfToken; $('password').value = ''; showDashboard(); await loadDashboard();
  } catch (e) { error.textContent = e.status === 401 ? 'Credenciales no válidas.' : e.message; }
  finally { button.disabled = false; }
});
$('logout').addEventListener('click', async () => {
  try { await request('/api/auth/logout', { method: 'POST', headers: { 'x-csrf-token': csrfToken } }); }
  catch { $('global-message').textContent = 'No se pudo confirmar el cierre de sesión. Vuelve a comprobar la sesión.'; return; }
  window.dispatchEvent(new Event('knjo:logout')); csrfToken = ''; showGate(false); $('global-message').textContent = '';
});
(async () => { try { await request('/api/auth/me'); const { body } = await request('/api/auth/csrf'); csrfToken = body.csrfToken; showDashboard(); await loadDashboard(); } catch { showGate(false); } })();
