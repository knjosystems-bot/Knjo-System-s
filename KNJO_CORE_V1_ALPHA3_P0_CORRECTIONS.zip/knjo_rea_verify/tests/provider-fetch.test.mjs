import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchProviderJson } from '../netlify/functions/_provider-fetch.mjs';

test('fetchProviderJson returns parsed provider JSON and HTTP response', async (t) => {
  const originalFetch = globalThis.fetch;
  t.after(() => { globalThis.fetch = originalFetch; });
  globalThis.fetch = async (_url, options) => {
    assert.ok(options.signal instanceof AbortSignal);
    return { status: 429, ok: false, json: async () => ({ error: { status: 'RESOURCE_EXHAUSTED' } }) };
  };
  const result = await fetchProviderJson('https://provider.invalid', {}, 100);
  assert.equal(result.response.status, 429);
  assert.equal(result.data.error.status, 'RESOURCE_EXHAUSTED');
});

test('fetchProviderJson aborts a request that exceeds its timeout', async (t) => {
  const originalFetch = globalThis.fetch;
  t.after(() => { globalThis.fetch = originalFetch; });
  globalThis.fetch = (_url, options) => new Promise((_resolve, reject) => {
    options.signal.addEventListener('abort', () => {
      const error = new Error('aborted'); error.name = 'AbortError'; reject(error);
    }, { once: true });
  });
  await assert.rejects(fetchProviderJson('https://provider.invalid', {}, 10), { name: 'AbortError' });
});

test('fetchProviderJson keeps the timeout active while reading the response body', async (t) => {
  const originalFetch = globalThis.fetch;
  t.after(() => { globalThis.fetch = originalFetch; });
  globalThis.fetch = async (_url, options) => ({
    status: 200, ok: true,
    json: () => new Promise((_resolve, reject) => options.signal.addEventListener('abort', () => {
      const error = new Error('body aborted'); error.name = 'AbortError'; reject(error);
    }, { once: true }))
  });
  await assert.rejects(fetchProviderJson('https://provider.invalid', {}, 10), { name: 'AbortError' });
});
