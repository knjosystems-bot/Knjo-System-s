import { authorizeAI, reply, parseBody } from './_ai-auth.mjs';
import { buildQualityContext } from './_ai-quality.mjs';
import { fetchProviderJson } from './_provider-fetch.mjs';
const MODEL = process.env.GEMINI_CHAT_MODEL || 'gemini-3.8-flash';
// Adjustable in Netlify without code changes; clamped to a safe range.
const configuredMaxTokens = Number.parseInt(process.env.GEMINI_CHAT_MAX_OUTPUT_TOKENS || '32768', 10);
const MAX_OUTPUT_TOKENS = Number.isFinite(configuredMaxTokens)
  ? Math.min(32768, Math.max(1024, configuredMaxTokens))
  : 32768;

export const handler = async (event) => {
  try {
    const auth=await authorizeAI(event); if(!auth.ok)return auth.response;
    const input=parseBody(event); if(!input||typeof input.message!=='string'||!input.message.trim()||input.message.length>12000) return reply(400,{error:{code:'INVALID_INPUT',message:'Escribe un mensaje de hasta 12,000 caracteres.'}});
    const apiKey=process.env.GEMINI_API_KEY; if(!apiKey) return reply(503,{error:{code:'AI_NOT_CONFIGURED',message:'Gemini aún no está configurado. Añade GEMINI_API_KEY en las variables de entorno de Netlify y vuelve a desplegar.'}});
    const quality = buildQualityContext(input.message.trim(), input.history);
    const history=quality.history.map(m=>({role:m.role,parts:[{text:m.text}]}));
    history.push({role:'user',parts:[{text:input.message.trim()}]});
    const { response, data } = await fetchProviderJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':apiKey},body:JSON.stringify({systemInstruction:{parts:[{text:quality.policy + `\nCLASE DE TAREA DETECTADA: ${quality.taskClass}. Si requiere búsqueda o verificación y no hay herramientas/fuentes en el contexto, no simules haberlas usado. Si solicita una acción sensible, no afirmes ejecutarla desde el chat sin una herramienta autorizada y confirmación aplicable.`}]},contents:history,generationConfig:{temperature:0.4,maxOutputTokens:MAX_OUTPUT_TOKENS}}),signal:undefined},45_000);
    if(!response.ok){
      const providerCode=String(data?.error?.status||data?.error?.code||'').toUpperCase();
      const providerMessage=String(data?.error?.message||'');
      const quota=/QUOTA_EXCEEDED|RESOURCE_EXHAUSTED/i.test(providerCode+' '+providerMessage);
      const rateLimited=response.status===429;
      const status=rateLimited?429:(response.status===400?400:response.status===401||response.status===403?502:502);
      const code=quota?'AI_QUOTA_EXCEEDED':rateLimited?'AI_RATE_LIMIT':response.status===400?'AI_REQUEST_REJECTED':response.status===401||response.status===403?'AI_PROVIDER_AUTH':'AI_PROVIDER_ERROR';
      const message=quota?'La cuota de Gemini se agotó para este proyecto o modelo. Revisa cuota y facturación en Google AI Studio.':rateLimited?'Gemini está limitando temporalmente las solicitudes. Espera un momento y vuelve a intentarlo.':response.status===400?'Gemini rechazó la solicitud. Revisa el modelo configurado y el contenido del mensaje.':response.status===401||response.status===403?'Gemini rechazó la credencial o los permisos del proyecto. Revisa GEMINI_API_KEY en Netlify.':'Gemini no pudo completar la solicitud por un error del proveedor. Inténtalo más tarde.';
      return reply(status,{error:{code,message}});
    }
    const text=(data?.candidates?.[0]?.content?.parts||[]).filter(p=>typeof p.text==='string').map(p=>p.text).join('\n').trim();
    if(!text)return reply(502,{error:{code:'AI_EMPTY_RESPONSE',message:'Gemini devolvió una respuesta vacía.'}});
    return reply(200,{text,model:MODEL});
  } catch(e) { return reply(502,{error:{code:e?.name==='AbortError'?'AI_TIMEOUT':'AI_UNAVAILABLE',message:e?.name==='AbortError'?'Gemini tardó demasiado. Inténtalo de nuevo.':'No fue posible conectar con Gemini en este momento.'}}); }
};
